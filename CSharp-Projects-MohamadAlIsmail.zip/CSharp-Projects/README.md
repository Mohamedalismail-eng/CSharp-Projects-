# C# Projects

These are some small projects I made using C# and .NET Framework.

## Projects:

- [Car Insurance](./CarInsurance)
- [NFL Stats](./NFLStats)

---

### Car Insurance

This is a placeholder MVC web application that mimics a car insurance website. It is designed to take user input and calculate quotes based on sample business logic. It also includes an admin page to view issued quotes. This project was created for learning purposes.

---

### NFL Stats

This is a placeholder data visualization MVC app that is meant to store and display football stats for fantasy football. It uses a mock Entity Framework 6 structure with Code First workflow. Still a work in progress.